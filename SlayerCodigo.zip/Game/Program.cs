﻿using System;

namespace Game;

class Program
{
    static void Main(string[] args)
    {
        Game slayer = new Game(100,100);
    }
}