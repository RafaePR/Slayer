Programa feito por Rafael Durand.

O programa consiste em um "jogo" básico de um duelo
no qual você, o jogador, luta contra um oponente,
o inimigo, em sistema de turnos automáticos, 
o dano dos dois é aleatório e ganha quem derrotar seu oponente.

Há também a possibilidade da batalha ser muito intensa e os
dois oponentes não aguentam e acabam morrendo, essa é a batalha épica.

